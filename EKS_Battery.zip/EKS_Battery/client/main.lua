local batteryStates = {} 


local function debugPrint(msg)
    if Config.Debug then
        print(('[EKS_BatteryRemoval] %s'):format(msg))
    end
end

local function LoadAnimDict(dict)
    if HasAnimDictLoaded(dict) then return end
    RequestAnimDict(dict)
    while not HasAnimDictLoaded(dict) do
        Wait(0)
    end
end

local function IsHoodOpen(vehicle)
    if not DoesEntityExist(vehicle) then return false end
    local ratio = GetVehicleDoorAngleRatio(vehicle, 4)
    return ratio and ratio > 0.1
end

local function IsBatteryRemoved(vehicle)
    if not DoesEntityExist(vehicle) then return false end
    local netId = NetworkGetNetworkIdFromEntity(vehicle)
    if not netId then return false end
    return batteryStates[netId] == true
end

local function SetBatteryRemoved(vehicle, removed)
    if not DoesEntityExist(vehicle) then return end

    local netId = NetworkGetNetworkIdFromEntity(vehicle)
    if not netId or netId == 0 then
        NetworkRegisterEntityAsNetworked(vehicle)
        netId = NetworkGetNetworkIdFromEntity(vehicle)
    end

    TriggerServerEvent('eks_battery:setBatteryState', netId, removed)
end

local function DoMechanicAction(ped, vehicle)
    TaskTurnPedToFaceEntity(ped, vehicle, 1000)
    Wait(950)

    LoadAnimDict(Config.MechanicAnim.dict)

    local duration = Config.RemoveTime or 5000

    TaskPlayAnim(
        ped,
        Config.MechanicAnim.dict,
        Config.MechanicAnim.anim,
        8.0,   -- blend in
        -8.0,  -- blend out
        duration,
        1,     -- loop
        0.0,
        false, false, false
    )

    local startTime = GetGameTimer()
    local cancelled = false

    while GetGameTimer() - startTime < duration do
        if not IsEntityPlayingAnim(ped, Config.MechanicAnim.dict, Config.MechanicAnim.anim, 3) then
            TaskPlayAnim(
                ped,
                Config.MechanicAnim.dict,
                Config.MechanicAnim.anim,
                8.0, -8.0,
                duration,
                1, 0.0,
                false, false, false
            )
        end

        local pCoords = GetEntityCoords(ped)
        local vCoords = GetEntityCoords(vehicle)

        if #(pCoords - vCoords) > (Config.InteractDistance + 1.0) then
            cancelled = true
            break
        end

        if not IsHoodOpen(vehicle) then
            cancelled = true
            break
        end

        DisableControlAction(0, 21, true) -- sprint
        DisableControlAction(0, 22, true) -- jump
        DisableControlAction(0, 24, true) -- attack
        DisableControlAction(0, 25, true) -- aim
        DisableControlAction(0, 32, true) -- W
        DisableControlAction(0, 33, true) -- S
        DisableControlAction(0, 34, true) -- A
        DisableControlAction(0, 35, true) -- D

        Wait(0)
    end

    ClearPedTasks(ped)

    return not cancelled
end


CreateThread(function()
    Wait(500)

    exports.ox_target:addGlobalVehicle({
        {
            name = 'eks_remove_battery',
            icon = 'fa-solid fa-car-battery',
            label = 'Remove Battery',
            distance = Config.InteractDistance,
            canInteract = function(entity, distance, coords, name)
                if distance > Config.InteractDistance then return false end
                if not IsHoodOpen(entity) then return false end
                if IsBatteryRemoved(entity) then return false end

                local ped = PlayerPedId()
                if IsPedInAnyVehicle(ped, false) then return false end

                return true
            end,
            onSelect = function(data)
                local vehicle = data.entity
                if not DoesEntityExist(vehicle) then return end
                if IsBatteryRemoved(vehicle) then
                    debugPrint('Battery already removed.')
                    return
                end

                local ped = PlayerPedId()

                local success = DoMechanicAction(ped, vehicle)
                if not success then
                    debugPrint('Battery removal cancelled.')
                    return
                end

                if not DoesEntityExist(vehicle) or not IsHoodOpen(vehicle) then
                    debugPrint('Vehicle or hood state invalid at finish (remove).')
                    return
                end

                SetBatteryRemoved(vehicle, true)

                SetVehicleEngineOn(vehicle, false, true, true)
                SetVehicleUndriveable(vehicle, true)

                BeginTextCommandThefeedPost('STRING')
                AddTextComponentSubstringPlayerName('~r~Battery removed~s~. This vehicle will not start until reinstalled.')
                EndTextCommandThefeedPostTicker(false, true)

                debugPrint('Battery removed for vehicle.')
            end
        },

        {
            name = 'eks_install_battery',
            icon = 'fa-solid fa-car-battery',
            label = 'Install Battery',
            distance = Config.InteractDistance,
            canInteract = function(entity, distance, coords, name)
                if distance > Config.InteractDistance then return false end
                if not IsHoodOpen(entity) then return false end
                if not IsBatteryRemoved(entity) then return false end

                local ped = PlayerPedId()
                if IsPedInAnyVehicle(ped, false) then return false end

                return true
            end,
            onSelect = function(data)
                local vehicle = data.entity
                if not DoesEntityExist(vehicle) then return end
                if not IsBatteryRemoved(vehicle) then
                    debugPrint('Battery is already installed.')
                    return
                end

                local ped = PlayerPedId()

                local success = DoMechanicAction(ped, vehicle)
                if not success then
                    debugPrint('Battery install cancelled.')
                    return
                end

                if not DoesEntityExist(vehicle) or not IsHoodOpen(vehicle) then
                    debugPrint('Vehicle or hood state invalid at finish (install).')
                    return
                end

                SetBatteryRemoved(vehicle, false)

                SetVehicleUndriveable(vehicle, false)

                BeginTextCommandThefeedPost('STRING')
                AddTextComponentSubstringPlayerName('~g~Battery installed~s~. Vehicle power restored.')
                EndTextCommandThefeedPostTicker(false, true)

                debugPrint('Battery installed for vehicle.')
            end
        }
    })
end)


RegisterNetEvent('eks_battery:updateBatteryState', function(netId, removed)
    if not netId then return end
    if removed then
        batteryStates[netId] = true
    else
        batteryStates[netId] = nil
    end
end)


CreateThread(function()
    while true do
        local wait = 500
        local ped = PlayerPedId()

        if IsPedInAnyVehicle(ped, false) then
            local vehicle = GetVehiclePedIsIn(ped, false)
            if DoesEntityExist(vehicle) then
                local netId = NetworkGetNetworkIdFromEntity(vehicle)
                if netId and batteryStates[netId] then
                    wait = 0
                    -- Only matters for the driver
                    if GetPedInVehicleSeat(vehicle, -1) == ped then
                        if GetIsVehicleEngineRunning(vehicle) then
                            SetVehicleEngineOn(vehicle, false, true, true)
                        end
                        SetVehicleUndriveable(vehicle, true)
                    end
                end
            end
        end

        Wait(wait)
    end
end)
