fx_version 'cerulean'
game 'gta5'

name 'EKS_BatteryRemoval'
description 'Simple battery removal script'
author 'Cowboy - Echo Kilo Studios'
lua54 'yes'

shared_script 'shared/config.lua'

client_scripts {
    'client/main.lua'
}

server_scripts {
    'server/main.lua'
}

dependencies {
    'ox_target'
}
