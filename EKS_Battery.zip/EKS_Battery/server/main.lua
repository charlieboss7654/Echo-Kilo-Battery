local BatteryRemoved = {}

RegisterNetEvent('eks_battery:setBatteryState', function(netId, removed)
    if not netId then return end

    if removed then
        BatteryRemoved[netId] = true
    else
        BatteryRemoved[netId] = nil
    end

    TriggerClientEvent('eks_battery:updateBatteryState', -1, netId, removed and true or false)
end)

AddEventHandler('entityRemoved', function(entity)
    if not entity or not DoesEntityExist(entity) then return end

    if IsEntityAVehicle(entity) then
        local netId = NetworkGetNetworkIdFromEntity(entity)
        if netId and BatteryRemoved[netId] then
            BatteryRemoved[netId] = nil
        end
    end
end)
