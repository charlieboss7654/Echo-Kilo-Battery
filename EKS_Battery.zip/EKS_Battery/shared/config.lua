Config = {}

-- How long it takes to remove the battery (ms)
Config.RemoveTime = 5000

-- Standing mechanic animation
Config.MechanicAnim = {
    dict = 'mini@repair',
    anim = 'fixing_a_ped'
}

-- Distance for interaction
Config.InteractDistance = 2.5

-- Debug prints
Config.Debug = false
